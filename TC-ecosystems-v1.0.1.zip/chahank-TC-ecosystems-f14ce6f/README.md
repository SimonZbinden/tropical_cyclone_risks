# TC-ecosystems
Code to replicate the results from the paper: Tropical cyclones risk for global ecosystems in a changing1 climate
